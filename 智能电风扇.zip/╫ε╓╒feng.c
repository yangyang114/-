#include <reg51.h>
#include<absacc.h>
#define uchar unsigned char
#define uint unsigned int
sbit P10 = P1^0;
sbit P11 = P1^1;
sbit P12 = P1^2;
sbit P13 = P1^3;
sbit P14 = P1^4;
sbit P15 = P1^5;
sbit P16 = P1^6;
sbit P17 = P1^7;
sbit beed= P2^0;
bit on_off = 0; //�ܿ���
uint level=0;//���ȵ�λ
bit p_status=0;//�ֶ�ģʽ����
bit auto_mode = 0; //�Զ�ģʽ����
bit set_time_mode = 0; // ��ʱģʽ����
bit sta=0;//���ض�ʱ��־
uint timer_count = 0;//��ʱ����ʱ��־
uchar hour = 0,min = 0,sec = 10;//��ʱʱ��
xdata uchar	DIGIT _at_ 0x8002;
xdata uchar	SEG	 _at_ 0x8004; 
xdata uchar DACS _at_ 0x9000;
#define my_data_ADC0 XBYTE[0XA000]
uchar xdata *ADCS;
uchar adresult;//AD���
char data now_temperature;//�¶�ֵ
uchar code SEGCC[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71,0x40}; //����ܶ�ѡ
uchar code SEGLOCAL[]={0x40,0x20,0x10,0x08,0x04,0x02,0x01}; //�����λѡ
uint code DA_LEVEL[]={0x7f,0xbc,0xde,0xff};//ת��
void myinit();
void init_time();
void showkey(uchar b,uchar pos);
void readADC();
void tem_level();
void sound();
void Delay150us();
void Delay(uint x);
void DelayMS(uint x) ;
void myinit()//��ʼ������
{
   EX1=1;
   ET1=1;
   EA=1;
   ADCS=0xa000;
   now_temperature=0;
}
void init_time()//��ʱ����ʼ������
{
	TMOD=0x01;
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	EA=1;
	ET0=1;
	TR0=0;
}
void time_0()interrupt 1//��ʱ���жϼ�ʱ���� 
{
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	timer_count++;
	if(timer_count == 20)
	{
		timer_count=0;
		if(set_time_mode == 1&& sta==1)//��ʱģʽ��,�Ž��е���ʱ
			  {
						if(sec==0)
						{
								sec = 59;
								if(min==0)
								{
										min = 59;
										if(hour==0)
										{
										    min = 0;
                                            sec = 0;//��ʾ����
										    on_off = 0;//����ֹͣ
											set_time_mode = 0;
						                    auto_mode = 0;
                                            TR0 = 0;//��ʱ��ֹͣ								
										}
										else
										{
												hour--;
										}
								}
								else
								{
										min--;
								}
						}
						else
						{
								sec--;
						}
				}
	}
}

void key()  //��ȡ��ť����
{
    
   if(P10==0)
   {
		 DelayMS(10);
		 if(P10==0)
		 {
			if(level<3&&p_status)
			{
				level++;
			}
		    while(!P10);
		 }
   }
   if(P11==0)
   {
		 DelayMS(10);
		 if(P11==0)
		 {
			 if(level>0&&p_status)
			{
				level--;
			}
	    	while(!P11);
		 }
      
   }
   if(P12==0)
   {
		 DelayMS(10);
		 if(P12==0)
		 {
		    level=1;
		    p_status=1;
			auto_mode=0;
			while(!P12);
		 }
      
   }
	 if (P13 == 0) // on and off
	 {
		 DelayMS(10);
		 if (P13 == 0)
		 {
		    if(on_off==1)
			{
		    on_off = 0;
			}
			else
			{
			on_off = 1;
			}
			while(!P13);
		 }
		 
	 }
	if (P14 == 0) // on and off
	 {
		 DelayMS(10);
		 if (P14 == 0)
		 {
		    auto_mode = 1;
			p_status=0;
			while(!P14);
		 }
		 
	 }
	if (P15 == 0) // set time
	 {
		 DelayMS(10);
		 if (P15 == 0)
		 {
            set_time_mode = ~set_time_mode;
			while(!P15);
		 }
		 
	 }
	 if (P16==0)
	 {
	     DelayMS(10);
		 if (P16 == 0)
		 {
		   if (set_time_mode == 1)
		   {
		     min+=30;
			 if(min>=60)
			 {
			 min=min-60;
			 hour++;
		     }
		     while(!P16);
		   }
         }
	 }
	 if (P17==0)
	 {
	     DelayMS(10);
		 if (P17 == 0)
		 {
		    sta=~sta;
			TR0=1;
			while(!P17);
		 }
	 }
}
void tem_level()  //���ܷ絵λ���ƺ���
{
    if (now_temperature <= 15) {level = 0;}
	if (now_temperature > 15 && now_temperature <= 21) {level = 1;}
	if (now_temperature > 21 && now_temperature <= 26) {level = 2;}
	if (now_temperature > 26) {level = 3;}
}
void main(void)
{ 
   uint i; 
   uint j;
   myinit();//��ʼ��
   while (1)
   {
		if (on_off == 1)
		{
			if (auto_mode == 0 && set_time_mode == 0) 
			{
				DACS=DA_LEVEL[level];
				DelayMS(10);
				readADC();
				showkey(level/10,1);
				showkey(level%10,2);
				showkey(16,3);
				showkey(16,4);
				showkey(now_temperature/10,5);
				showkey(now_temperature%10,6);
				key();
			}
			else if (auto_mode == 1 && set_time_mode == 0)
			{
				readADC();
				tem_level();
				DACS=DA_LEVEL[level];
				DelayMS(10);
				showkey(level/10,1);
				showkey(level%10,2);
				showkey(16,3);
				showkey(16,4);
				showkey(now_temperature/10,5);
				showkey(now_temperature%10,6);
				key();
			}
			else if (auto_mode == 0 && set_time_mode == 1)
			{
				init_time();
				while(set_time_mode)
				{
				    key();
					DACS=DA_LEVEL[level];
					DelayMS(10);
					readADC();
					showkey(hour/10,1);
				    showkey(hour%10,2);
				    showkey(min/10,3);
					showkey(min%10,4);
					showkey(sec/10,5);
					showkey(sec%10,6);
					if (sta== 1)
					{   
						DACS=DA_LEVEL[level];
						DelayMS(10);
						readADC();
						for (j=100;j>0;j--)
						{
						showkey(level/10,1);
			        	showkey(level%10,2);
			        	showkey(16,3);
				        showkey(16,4);
				        showkey(now_temperature/10,5);
				        showkey(now_temperature%10,6);
						}
						//DelayMS(500);
						for (j=100;j>0;j--)
						{
						showkey(hour/10,1);
						showkey(hour%10,2);
						showkey(min/10,3);
						showkey(min%10,4);
						showkey(sec/10,5);
						showkey(sec%10,6);
						}
						if(hour==0&& min==0&& sec<=2)
						{
						sound();
						}
						key();
					}
				}
			}
			else if (auto_mode == 1 && set_time_mode == 1)
			{
				init_time();
				while(set_time_mode)
				{
				    key();
			        readADC();
                    tem_level();
                    DACS=DA_LEVEL[level];
                    DelayMS(10);
                    showkey(hour/10,1);
				    showkey(hour%10,2);
				    showkey(min/10,3);
					showkey(min%10,4);
					showkey(sec/10,5);
					showkey(sec%10,6);
					if (sta== 1)
					{
					    readADC();
				        tem_level();
				        DACS=DA_LEVEL[level];
				        DelayMS(10);
						for (j=100;j>0;j--)
						{
				        showkey(level/10,1);
				        showkey(level%10,2);
				        showkey(16,3);
				        showkey(16,4);
				        showkey(now_temperature/10,5);
				        showkey(now_temperature%10,6);
						}
						//DelayMS(500);
						for (j=100;j>0;j--)
						{
						showkey(hour/10,1);
						showkey(hour%10,2);
						showkey(min/10,3);
						showkey(min%10,4);
						showkey(sec/10,5);
						showkey(sec%10,6);
						}
						if(hour==0&& min==0&& sec<=2)
						{
						sound();
						}
						key();
					}
				}
			}
		}
		else
		{
				level = 0;
				DACS=DA_LEVEL[level];
				Delay(10);
				for (i = 1; i < 7; i++) 
				{
					showkey(16,i);
				}
				key();
		}
		
   }
}

void showkey(uchar b,uchar pos)   //�������ʾ����
{
    
   DIGIT=SEGLOCAL[pos];
   SEG=SEGCC[b];
   DelayMS(1);
   SEG=0x00;
}

void readADC()  //ͨ��AD��ȡ�¶Ⱥ���
{
  *ADCS = 0;                
  DelayMS(1);
  adresult=my_data_ADC0;
  now_temperature=2500/adresult;

}

void sound()  //����������
{
unsigned char a,b;
	for(a=10;a>0;a--)
	for(b=78;b>0;b--)
	{
      beed=!beed;
      Delay150us();
	}
}

void Delay150us()		//@12.000MHz
{
	unsigned char i, j;

	i = 2;
	j = 189;
	do
	{
		while (--j);
	} while (--i);
}

void Delay(uint x)
{
  uint i;
  while (x-- !=0)
  {
   for (i=100; i !=0; i--);
  }
}

void DelayMS(uint x) 
{  
   uchar i;
   while(x--)
    {
	 for(i=80;i>0;i--);
    }
}